# Hispanic Heritage Historical Data Explorer

A single-file Streamlit classroom app for exploring World Bank historical indicators, editing a transparent scenario table, fitting centered-time polynomial models, analyzing functions and derivatives, and exporting CSV, Excel, and PDF reports.

## Files

- `app.py` — complete application; no custom modules or local data files required.
- `requirements.txt` — minimal unpinned dependency list for Streamlit-friendly deployment.
- `sources.md` — source and indicator notes.

## Run locally

Use Python 3.10+ (Python 3.11 is a sensible default) in a virtual environment:

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
.venv\Scripts\Activate.ps1

pip install -r requirements.txt
python -m streamlit run app.py
```

The app calls the public World Bank API; an internet connection is needed for historical data. No API key or credentials are required.

## Deploy on GitHub + Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt` (optionally include `README.md` and `sources.md`).
3. Open [Streamlit Community Cloud](https://share.streamlit.io/), sign in with GitHub, and choose **Create app**.
4. Select the repository, branch, and `app.py` as the main file.
5. Deploy. If dependencies fail, inspect the app's deployment logs and confirm the repository contains the exact `requirements.txt` filename.

## Deploy on Render

Create a **Python Web Service** connected to the GitHub repository.

- **Build command**
  ```bash
  pip install -r requirements.txt
  ```
- **Start command** (single line)
  ```bash
  python -m streamlit run app.py --server.address=0.0.0.0 --server.port=$PORT
  ```

The service must bind to `0.0.0.0` and Render's `$PORT`. No credentials are needed.

## Verification checklist

- **Source accuracy:** choose a country and indicator; compare the indicator code, definition, units, retrieval date, and actual coverage with the linked World Bank indicator/API page.
- **Editing/reset:** edit a value or year, confirm the user-modified warning and model changes, then press **Reset to source**.
- **Validation:** try duplicate years, a non-integer year, nonnumeric value, a negative life expectancy, or unemployment above 100. Errors should be shown and fitting should stop for invalid tables.
- **Insufficient observations:** choose a high polynomial degree with too few distinct valid years. The app should explain the minimum \(d+1\) requirement.
- **Equation and metrics:** verify the centered-time equation, base year, in-sample R²/MAE, residual table, mean, and observation count.
- **Single/batch agreement:** calculate a year with **Calculate Value**, then request the same year in batch mode; the estimates should agree up to floating-point rounding.
- **API failures:** temporarily disconnect network access or use the browser developer/network tools to simulate a failed request. The app should show an understandable error, not fabricate values.
- **Controls:** change country, indicator, degree, sample increment, horizon, comparison countries, printer view, pathway, context, function, interval, current point, visible curves, and visual metaphor. Confirm each affects its intended output. The forward horizon is a display control for the historical explorer; predictions are requested explicitly in the year and batch controls.
- **Exports:** download CSV, `.xlsx`, and PDF; open each with its appropriate application. Excel must contain Summary, Working Data, and Calculated Years sheets.
- **Deployment:** check the live app URL, API access, calculations, and downloads. Review logs if a deployed dependency or API request fails.

## Important implementation notes

- The data request spans current year minus 70 through current year minus 1, inclusive. It does not promise 70 non-null observations.
- The polynomial is fit against centered time `year - base_year` and uses that same transformation for every estimate.
- Polynomial extrapolations can be unstable. The app does not clip predictions or claim a 95% prediction interval.
- Function Lab accepts expressions using `t`, arithmetic, powers, parentheses, and allowlisted functions (`sin`, `cos`, `tan`, `exp`, `log`, `sqrt`, `abs`, etc.). Use explicit multiplication such as `2*t`.
- Some calculus results are numerical approximations. Inflection points are only listed when a concavity change is detected; a zero of the second derivative alone is not sufficient.
- The simulation is a classroom visual metaphor, not a clinical, engineering, or weather decision tool. Streamlit's rerun model means the play control advances on reruns rather than running an independent background animation timer.

## Troubleshooting

- **`ModuleNotFoundError`:** ensure the virtual environment is active and rerun `pip install -r requirements.txt`.
- **World Bank timeout/connection error:** check internet access, retry later, and inspect hosting logs. Missing API observations are not replaced with made-up values.
- **Polynomial fit error:** degree \(d\) needs at least \(d+1\) distinct valid years; lower the degree or restore more valid rows.
- **Invalid expression:** use `t`, `*` for multiplication, parentheses, and supported function names. For example `a` is not an available free parameter in the custom expression field; use Parameterized function mode instead.
- **Blank charts or domain warnings:** the function may be undefined over some of the selected interval (for example, a denominator is zero or a logarithm argument is nonpositive).
- **Export error:** inspect the Streamlit logs and verify ReportLab/XlsxWriter installed successfully.
