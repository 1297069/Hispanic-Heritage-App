"""
Hispanic Heritage Historical Data Explorer
A self-contained Streamlit app for World Bank historical data, polynomial fitting,
student-editable scenarios, exports, and interactive function/calculus exploration.

Run: python -m streamlit run app.py
"""
from __future__ import annotations

import io
import math
import re
import textwrap
from datetime import date, datetime, timezone
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
import streamlit as st
import sympy as sp
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from sklearn.metrics import mean_absolute_error, r2_score

APP_TITLE = "Hispanic Heritage Historical Data Explorer"
COUNTRIES = {
    "Mexico (MX)": "MEX", "Brazil (BR)": "BRA", "Argentina (AR)": "ARG",
    "Colombia (CO)": "COL", "Chile (CL)": "CHL", "Peru (PE)": "PER",
    "Venezuela (VE)": "VEN", "Ecuador (EC)": "ECU", "Uruguay (UY)": "URY",
}
INDICATORS = {
    "Life expectancy at birth": ("SP.DYN.LE00.IN", "years",
        "Expected years a newborn would live if current age-specific mortality patterns persisted."),
    "Unemployment, national estimate": ("SL.UEM.TOTL.NE.ZS", "% of labor force",
        "Share of the labor force without work but available for and seeking employment, using national estimates."),
    "GDP per capita": ("NY.GDP.PCAP.CD", "current US$ per person",
        "Gross domestic product divided by midyear population. It is not average wealth or household income."),
    "Crude birth rate": ("SP.DYN.CBRT.IN", "births per 1,000 people per year",
        "Annual live births per 1,000 people; this is a rate, not a birth count."),
    "Net migration": ("SM.POP.NETM", "people (net total)",
        "Number of immigrants minus emigrants over the period. It is not an emigration count."),
    "Intentional homicide rate": ("VC.IHR.PSRC.P5", "intentional homicides per 100,000 people",
        "Intentional homicide victims per 100,000 population."),
    "Consumer price inflation": ("FP.CPI.TOTL.ZG", "% annual change",
        "Annual percentage change in the consumer price index."),
    "Central government debt": ("GC.DOD.TOTL.GD.ZS", "% of GDP",
        "Central government debt as a share of gross domestic product."),
    "Total reserves including gold": ("FI.RES.TOTL.CD", "current US$",
        "Total reserves, including gold, valued in current US dollars."),
    "External balance on goods/services": ("NE.RSB.GNFS.ZS", "% of GDP",
        "External balance on goods and services as a share of GDP."),
}
WB_API = "https://api.worldbank.org/v2/country/{country}/indicator/{indicator}"
WB_COUNTRY = "https://data.worldbank.org/indicator/{indicator}?locations={country}"
CURRENT_YEAR = date.today().year
FIRST_YEAR, LAST_YEAR = CURRENT_YEAR - 70, CURRENT_YEAR - 1
YEAR_MIN, YEAR_MAX = 1950, 2100
T = sp.symbols("t", real=True)
SAFE_FUNCTIONS = {
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan, "asin": sp.asin,
    "acos": sp.acos, "atan": sp.atan, "exp": sp.exp, "log": sp.log,
    "sqrt": sp.sqrt, "abs": sp.Abs, "pi": sp.pi, "E": sp.E,
}
CONTEXTS = {
    "Business": ("Revenue", "dollars", "time", "months", "A business indicator can represent revenue, cost, or demand."),
    "Engineering": ("Position", "meters", "time", "seconds", "Position changes over time; its derivatives can represent velocity and acceleration."),
    "Medical": ("Concentration", "mg/L", "time", "hours", "A concentration curve is illustrative, not medical dosing guidance."),
    "Sports science": ("Distance", "meters", "time", "seconds", "A movement curve can represent distance or position during activity."),
    "Biology": ("Population", "organisms", "time", "days", "Population curves can model growth or decline over a stated interval."),
    "Bioengineering": ("Signal", "arbitrary units", "time", "seconds", "A signal curve can represent a measured biological or engineered response."),
    "Economic forecasting": ("GDP per capita", "current US$ per person", "year", "years", "Historical GDP per capita is an indicator, not household income or average wealth."),
    "Weather": ("Temperature", "°C", "time", "hours", "A temperature curve is illustrative and does not replace a forecast."),
    "Custom": ("Output", "units", "input", "units", "Describe the context and units for your own function."),
}
SUGGESTED_FUNCTIONS = {
    "Business": "a*(t-h)**2+k",
    "Engineering": "a*sin(b*t)+k",
    "Medical": "a*exp(-b*t)+k",
    "Sports science": "a*t+b",
    "Biology": "K/(1+exp(-r*(t-h)))",
    "Bioengineering": "a*sin(b*t)+c",
    "Economic forecasting": "a*t**2+b*t+c",
    "Weather": "a*cos(b*t)+c",
    "Custom": "a*t+b",
}
VISUALS = ["Walking person / prosthetic-leg example", "Moving object / projectile", "Tank / concentration indicator",
           "Population / cell colony", "Thermometer / weather indicator", "Business / economic indicator"]

st.set_page_config(page_title=APP_TITLE, page_icon="📈", layout="wide")
st.title("📈 " + APP_TITLE)
st.caption("HISPANIC HERITAGE DATA LAB · Historical indicators + mathematical modeling")
st.info("Brazil is included as a Latin American comparison country. The country list includes Hispanic-majority countries and Brazil as a regional comparison; Brazil is Portuguese-speaking, not a Hispanic country.")

@st.cache_data(ttl=3600, show_spinner=False)
def fetch_world_bank(country: str, indicator: str, start_year: int, end_year: int) -> tuple[pd.DataFrame, str]:
    """Fetch authentic World Bank API observations; missing values stay missing."""
    url = WB_API.format(country=country, indicator=indicator)
    params = {"format": "json", "per_page": 20000, "date": f"{start_year}:{end_year}"}
    try:
        response = requests.get(url, params=params, timeout=20)
        response.raise_for_status()
        payload = response.json()
    except requests.Timeout as exc:
        raise RuntimeError("The World Bank request timed out. Try again later or check the deployment logs.") from exc
    except requests.RequestException as exc:
        raise RuntimeError(f"Could not reach the World Bank API: {exc}") from exc
    except ValueError as exc:
        raise RuntimeError("The World Bank API returned invalid JSON.") from exc
    if not isinstance(payload, list) or len(payload) < 2:
        message = payload[0].get("message", []) if isinstance(payload, list) and payload else []
        raise RuntimeError(f"The World Bank API returned no usable data. API message: {message}")
    rows = []
    for item in payload[1] or []:
        if not item:
            continue
        value = item.get("value")
        try:
            numeric = float(value) if value is not None else np.nan
        except (TypeError, ValueError):
            numeric = np.nan
        rows.append({"year": int(item["date"]), "value": numeric})
    frame = pd.DataFrame(rows, columns=["year", "value"])
    if frame.empty:
        return frame, response.url
    frame = frame[(frame.year >= start_year) & (frame.year <= end_year)].sort_values("year")
    return frame.reset_index(drop=True), response.url

def constraint_message(indicator_label: str, value: float) -> str | None:
    if not np.isfinite(value):
        return "Values must be finite numbers."
    if indicator_label in ("Life expectancy at birth", "Unemployment, national estimate",
                           "Crude birth rate", "Intentional homicide rate", "Central government debt",
                           "Total reserves including gold"):
        if value < 0:
            return "This indicator cannot be negative."
    if indicator_label == "Life expectancy at birth" and value > 125:
        return "Life expectancy above 125 years is implausible; check the value."
    if indicator_label == "Unemployment, national estimate" and value > 100:
        return "A percentage of the labor force must be between 0 and 100."
    if indicator_label == "Crude birth rate" and value > 100:
        return "This crude birth rate is implausibly high; check the value."
    if indicator_label == "Intentional homicide rate" and value > 500:
        return "This homicide rate is implausibly high; check the value."
    return None

def validate_working_data(frame: pd.DataFrame, indicator_label: str) -> tuple[pd.DataFrame, list[str]]:
    errors = []
    if not {"year", "value"}.issubset(frame.columns):
        return pd.DataFrame(columns=["year", "value"]), ["The editable table must contain year and value columns."]
    result = frame[["year", "value"]].copy()
    years, values = [], []
    for idx, raw in enumerate(result["year"].tolist(), start=1):
        try:
            if pd.isna(raw) or float(raw) != int(float(raw)):
                raise ValueError
            y = int(float(raw))
            if y < YEAR_MIN or y > YEAR_MAX:
                errors.append(f"Row {idx}: year must be between {YEAR_MIN} and {YEAR_MAX}.")
            years.append(y)
        except (ValueError, TypeError, OverflowError):
            errors.append(f"Row {idx}: year must be an integer.")
            years.append(None)
    for idx, raw in enumerate(result["value"].tolist(), start=1):
        try:
            if pd.isna(raw) or str(raw).strip() == "":
                values.append(np.nan)
                continue
            v = float(raw)
            message = constraint_message(indicator_label, v)
            if message:
                errors.append(f"Row {idx}: {message}")
            values.append(v)
        except (ValueError, TypeError):
            errors.append(f"Row {idx}: value must be numeric or blank.")
            values.append(np.nan)
    result["year"] = years
    result["value"] = values
    valid_years = [y for y in years if y is not None]
    if len(valid_years) != len(set(valid_years)):
        errors.append("Duplicate years are not allowed.")
    result = result.dropna(subset=["year", "value"])
    if not result.empty:
        result["year"] = result["year"].astype(int)
        result = result.sort_values("year").reset_index(drop=True)
    return result, errors

def fit_polynomial(frame: pd.DataFrame, degree: int):
    clean = frame.dropna(subset=["year", "value"]).sort_values("year")
    if clean["year"].nunique() < degree + 1:
        raise ValueError(f"Degree {degree} requires at least {degree + 1} distinct valid years; found {clean['year'].nunique()}.")
    base_year = int(clean["year"].min())
    x = clean["year"].to_numpy(dtype=float) - base_year
    y = clean["value"].to_numpy(dtype=float)
    if len(np.unique(x)) < degree + 1:
        raise ValueError("There are not enough distinct years for this degree.")
    coeff = np.polyfit(x, y, degree)
    poly = np.poly1d(coeff)
    fitted = poly(x)
    residuals = y - fitted
    r2 = float(r2_score(y, fitted)) if len(y) >= 2 else float("nan")
    mae = float(mean_absolute_error(y, fitted))
    coef_lines = [f"{c:.10g}" for c in coeff]
    terms = []
    for power, c in zip(range(degree, -1, -1), coeff):
        if power == 0:
            terms.append(f"({c:.10g})")
        elif power == 1:
            terms.append(f"({c:.10g})·t")
        else:
            terms.append(f"({c:.10g})·t^{power}")
    equation = "y = " + " + ".join(terms) + f", where t = year − {base_year}"
    out = clean.copy()
    out["fitted"] = fitted
    out["residual"] = residuals
    return {"base_year": base_year, "degree": degree, "coeff": coeff, "poly": poly,
            "equation": equation, "r2": r2, "mae": mae, "residuals": out,
            "count": len(clean), "min_year": int(clean.year.min()), "max_year": int(clean.year.max()),
            "mean": float(np.mean(y)), "x": x, "y": y}

def chronological_holdout(frame: pd.DataFrame, degree: int):
    clean = frame.dropna(subset=["year", "value"]).sort_values("year")
    n = len(clean)
    if n < max(2 * (degree + 1), 10):
        return None
    split = max(degree + 1, int(n * 0.8))
    if n - split < 1:
        return None
    train, test = clean.iloc[:split], clean.iloc[split:]
    base = int(train.year.min())
    model = np.poly1d(np.polyfit(train.year.to_numpy(float) - base, train.value.to_numpy(float), degree))
    pred = model(test.year.to_numpy(float) - base)
    return {"train_n": len(train), "test_n": len(test), "mae": float(mean_absolute_error(test.value, pred)),
            "r2": float(r2_score(test.value, pred)) if len(test) >= 2 else None}

def evaluate_poly(model, year):
    return float(model["poly"](float(year) - model["base_year"]))

def safe_parse_expression(expression: str):
    """Parse familiar math notation with SymPy; reject symbols and functions outside an allowlist."""
    cleaned = expression.replace("^", "**").replace("π", "pi")
    if len(cleaned) > 240:
        raise ValueError("Function expression is too long.")
    try:
        expr = sp.sympify(cleaned, locals={"t": T, **SAFE_FUNCTIONS}, evaluate=True)
    except Exception as exc:
        raise ValueError("Could not parse this expression. Use t, numbers, + − * /, powers, parentheses, and allowed functions such as sin(t), exp(t), log(t), sqrt(t).") from exc
    allowed_symbols = expr.free_symbols
    if not allowed_symbols.issubset({T}):
        raise ValueError("Use only t as the variable. For parameterized suggestions, adjust the parameter controls instead.")
    allowed_functions = set(SAFE_FUNCTIONS.values())
    for node in sp.preorder_traversal(expr):
        if isinstance(node, sp.Function) and node.func not in allowed_functions:
            raise ValueError(f"Unsupported function: {node.func}.")
    return sp.simplify(expr)

def real_numeric(expr, x):
    fn = sp.lambdify(T, expr, modules=["numpy"])
    with np.errstate(all="ignore"):
        value = fn(np.asarray(x, dtype=float))
    return np.asarray(value, dtype=float)

def numerical_domain_note(expr, low, high):
    notes = []
    denom = sp.denom(sp.together(expr))
    if denom != 1:
        roots = sp.solve(sp.Eq(denom, 0), T)
        real_roots = []
        for root in roots:
            try:
                z = complex(sp.N(root))
                if abs(z.imag) < 1e-8 and low <= z.real <= high:
                    real_roots.append(float(z.real))
            except Exception:
                pass
        if real_roots:
            notes.append("Possible rational discontinuity/undefined point(s) in interval near " + ", ".join(f"{x:.5g}" for x in real_roots) + ".")
    for node in sp.preorder_traversal(expr):
        if node.func == sp.log:
            arg = node.args[0]
            try:
                fn = sp.lambdify(T, arg, modules=["numpy"])
                vals = np.asarray(fn(np.linspace(low, high, 500)), dtype=float)
                if np.any(vals <= 0):
                    notes.append("Logarithm domain requires its argument to be positive; some plotted inputs may be undefined.")
                    break
            except Exception:
                notes.append("Check the logarithm domain before interpreting this interval.")
                break
        if node.func == sp.sqrt:
            notes.append("Square-root terms require nonnegative radicands over the real domain.")
            break
    return notes

def calculus_analysis(expr, low, high, point):
    d1, d2 = sp.diff(expr, T), sp.diff(expr, T, 2)
    f = sp.lambdify(T, expr, modules=["numpy"])
    fp = sp.lambdify(T, d1, modules=["numpy"])
    fpp = sp.lambdify(T, d2, modules=["numpy"])
    def scalar(fn, x):
        try:
            val = float(np.asarray(fn(float(x))))
            return val if np.isfinite(val) else None
        except Exception:
            return None
    candidates = []
    try:
        roots = sp.solveset(sp.Eq(d1, 0), T, domain=sp.Interval(low, high))
        if isinstance(roots, sp.FiniteSet):
            candidates.extend(float(sp.N(r)) for r in roots if abs(complex(sp.N(r)).imag) < 1e-8)
    except Exception:
        pass
    # Numerical fallback for critical points where exact solving is unavailable.
    grid = np.linspace(low, high, 1500)
    derivative_values = np.array([scalar(fp, z) if scalar(fp, z) is not None else np.nan for z in grid])
    for i in range(1, len(grid)):
        a, b = derivative_values[i-1], derivative_values[i]
        if np.isfinite(a) and np.isfinite(b) and a * b < 0:
            try:
                from scipy.optimize import brentq
                candidates.append(float(brentq(lambda z: scalar(fp, z), grid[i-1], grid[i])))
            except Exception:
                pass
    candidates = sorted(set(round(c, 7) for c in candidates if low < c < high))
    crit = []
    for c in candidates:
        eps = max((high-low)*1e-5, 1e-5)
        left, right = scalar(fp, c-eps), scalar(fp, c+eps)
        kind = "stationary point (not classified as an extremum)"
        if left is not None and right is not None:
            if left > 0 and right < 0: kind = "local maximum (first derivative changes + to −)"
            elif left < 0 and right > 0: kind = "local minimum (first derivative changes − to +)"
        crit.append({"x": c, "y": scalar(f,c), "kind": kind, "d2": scalar(fpp,c)})
    inflect = []
    try:
        roots2 = sp.solveset(sp.Eq(d2, 0), T, domain=sp.Interval(low, high))
        roots2_list = list(roots2) if isinstance(roots2, sp.FiniteSet) else []
        for root in roots2_list:
            z = float(sp.N(root))
            if low < z < high:
                eps = max((high-low)*1e-5, 1e-5)
                l, r = scalar(fpp,z-eps), scalar(fpp,z+eps)
                if l is not None and r is not None and l*r < 0:
                    inflect.append({"x": z, "y": scalar(f,z), "kind": "inflection point (concavity changes)"})
    except Exception:
        pass
    # Absolute extrema on closed interval only among finite endpoint and critical values.
    candidates_abs = [(low, scalar(f, low), "left endpoint"), (high, scalar(f, high), "right endpoint")]
    candidates_abs += [(c["x"], c["y"], c["kind"]) for c in crit]
    finite_abs = [(x,y,k) for x,y,k in candidates_abs if y is not None]
    abs_min = min(finite_abs, key=lambda z:z[1]) if finite_abs else None
    abs_max = max(finite_abs, key=lambda z:z[1]) if finite_abs else None
    ypoint, slope, second = scalar(f, point), scalar(fp, point), scalar(fpp, point)
    secant_slope = None
    if high != low:
        yl, yh = scalar(f, low), scalar(f, high)
        if yl is not None and yh is not None:
            secant_slope = (yh-yl)/(high-low)
    return {"d1": d1, "d2": d2, "crit": crit, "inflect": inflect,
            "fpoint": ypoint, "slope": slope, "second": second,
            "secant_slope": secant_slope, "abs_min": abs_min, "abs_max": abs_max,
            "f": f, "fp": fp, "fpp": fpp}

def make_chart(frame, model, indicator, unit, single_year=None, single_value=None,
               batch=None, sample_increment=1, comparison=None, title=None, horizon=0):
    fig, ax = plt.subplots(figsize=(10, 4.8))
    if not frame.empty:
        ax.scatter(frame.year, frame.value, label="Observed / working data", s=22, zorder=4)
    if model is not None:
        xs = np.linspace(model["min_year"], model["max_year"], max(250, model["count"] * 8))
        ax.plot(xs, model["poly"](xs-model["base_year"]), label="Polynomial fit (historical range)", linewidth=2)
        ax.axvline(model["max_year"], linestyle="--", linewidth=1, label="Historical boundary")
        if horizon > 0:
            future_xs = np.linspace(model["max_year"], model["max_year"] + horizon, max(80, horizon * 8))
            ax.plot(future_xs, model["poly"](future_xs-model["base_year"]), linestyle="--",
                    linewidth=1.6, label=f"Polynomial extrapolation (+{horizon} years)")
        sample_years = np.arange(model["min_year"], model["max_year"]+1, sample_increment)
        if len(sample_years):
            sample_values = model["poly"](sample_years-model["base_year"])
            ax.scatter(sample_years, sample_values, s=12, marker="x", label=f"Fit samples every {sample_increment} year(s)")
    if comparison:
        for name, cframe in comparison.items():
            if not cframe.empty:
                ax.plot(cframe.year, cframe.value, marker=".", linewidth=1.3, label=f"{name} (observed)")
    if single_year is not None and single_value is not None:
        outside = model is not None and (single_year < model["min_year"] or single_year > model["max_year"])
        ax.scatter([single_year], [single_value], s=75, marker="*", label="Calculated year estimate" + (" (outside range)" if outside else ""))
        if model is not None and outside:
            ax.plot([model["max_year"], single_year], [model["poly"](model["max_year"]-model["base_year"]), single_value],
                    linestyle=":", linewidth=1, label="Extrapolated segment")
    if batch is not None and not batch.empty:
        ax.scatter(batch["year"], batch["estimate"], marker="D", s=25, label="Batch estimates")
    ax.set_xlabel("Year")
    ax.set_ylabel(f"{indicator} ({unit})")
    ax.set_title(title or f"{indicator}: historical observations and fitted model")
    ax.grid(True, alpha=.25)
    ax.legend(loc="best", fontsize=8)
    fig.tight_layout()
    return fig

def csv_bytes(df):
    return df.to_csv(index=False).encode("utf-8")

def excel_bytes(summary: dict, working: pd.DataFrame, results: pd.DataFrame) -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        pd.DataFrame([summary]).to_excel(writer, sheet_name="Summary", index=False)
        working.to_excel(writer, sheet_name="Working Data", index=False)
        results.to_excel(writer, sheet_name="Calculated Years", index=False)
        for sheet, data in [("Summary", pd.DataFrame([summary])), ("Working Data", working), ("Calculated Years", results)]:
            ws = writer.sheets[sheet]
            ws.freeze_panes(1, 0)
            ws.set_column(0, max(0, len(data.columns)-1), 22)
    return output.getvalue()

def pdf_bytes(summary: dict, working: pd.DataFrame, results: pd.DataFrame, fig=None) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(letter), rightMargin=35, leftMargin=35, topMargin=30, bottomMargin=30)
    styles = getSampleStyleSheet()
    story = [Paragraph(APP_TITLE, styles["Title"]), Spacer(1, 8)]
    for key, value in summary.items():
        story.append(Paragraph(f"<b>{key}:</b> {str(value)[:500]}", styles["BodyText"]))
    story.append(Spacer(1, 10))
    if fig is not None:
        image_buffer = io.BytesIO()
        fig.savefig(image_buffer, format="png", dpi=130, bbox_inches="tight")
        image_buffer.seek(0)
        story.append(Image(image_buffer, width=9.2*inch, height=4.0*inch))
        story.append(Spacer(1, 8))
    story.append(Paragraph("Working data preview (first 30 rows)", styles["Heading2"]))
    preview = working.head(30).fillna("").astype(str)
    table_data = [list(preview.columns)] + preview.values.tolist() if len(preview.columns) else [["No data"]]
    tbl = Table(table_data, repeatRows=1)
    tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("GRID",(0,0),(-1,-1),.3,colors.grey),
                             ("FONTSIZE",(0,0),(-1,-1),7),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story.append(tbl)
    story.append(Spacer(1, 8))
    story.append(Paragraph("Calculated-year results", styles["Heading2"]))
    r = results.head(40).fillna("").astype(str)
    rdata = [list(r.columns)] + r.values.tolist() if len(r.columns) else [["No calculated results"]]
    rt = Table(rdata, repeatRows=1)
    rt.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.lightgrey),("GRID",(0,0),(-1,-1),.3,colors.grey),("FONTSIZE",(0,0),(-1,-1),7)]))
    story.append(rt)
    doc.build(story)
    return buffer.getvalue()

# Session state is used so the editor and calculated results survive ordinary reruns.
if "original_frame" not in st.session_state:
    st.session_state.original_frame = pd.DataFrame(columns=["year", "value"])
if "working_frame" not in st.session_state:
    st.session_state.working_frame = pd.DataFrame(columns=["year", "value"])
if "data_key" not in st.session_state:
    st.session_state.data_key = None
if "calculated_years" not in st.session_state:
    st.session_state.calculated_years = []
if "calculated_results" not in st.session_state:
    st.session_state.calculated_results = pd.DataFrame(columns=["year", "estimate", "units", "classification", "status"])
if "calculation_key" not in st.session_state:
    st.session_state.calculation_key = None

with st.sidebar:
    st.header("Historical data")
    country_label = st.selectbox("Featured country", list(COUNTRIES))
    country_code = COUNTRIES[country_label]
    indicator_label = st.selectbox("Indicator", list(INDICATORS))
    indicator_code, unit, definition = INDICATORS[indicator_label]
    degree = st.slider("Polynomial degree", 3, 8, 3)
    sample_increment = st.slider("Graph sample increment (years)", 1, 10, 1)
    horizon = st.slider("Forward display horizon (years)", 0, 50, 10)
    printer_mode = st.checkbox("Printer-friendly report view", False)
    st.caption(f"Requested API period: {FIRST_YEAR}–{LAST_YEAR} (current year −70 through −1).")
    st.header("Comparison")
    comparison_labels = st.multiselect("Compare same indicator in", [x for x in COUNTRIES if x != country_label], default=[])

data_key = (country_code, indicator_code, FIRST_YEAR, LAST_YEAR)
if st.session_state.data_key != data_key:
    try:
        with st.spinner("Retrieving World Bank observations…"):
            fetched, source_url = fetch_world_bank(country_code, indicator_code, FIRST_YEAR, LAST_YEAR)
        st.session_state.original_frame = fetched.copy()
        st.session_state.working_frame = fetched.copy()
        st.session_state.data_key = data_key
        st.session_state.calculated_years = []
        st.session_state.calculated_results = pd.DataFrame(columns=["year", "estimate", "units", "classification", "status"])
        st.session_state.calculation_key = None
        st.session_state.source_url = source_url
    except RuntimeError as exc:
        st.error(str(exc))
        st.markdown(f"[World Bank indicator source]({WB_COUNTRY.format(indicator=indicator_code, country=country_code)})")
        st.stop()

original = st.session_state.original_frame.copy()
working_before_edit = st.session_state.working_frame.copy()
st.subheader("Source and coverage")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Non-missing source observations", f"{len(original.dropna(subset=['value'])):,}")
col2.metric("Coverage", f"{int(original.year.min()) if not original.empty else '—'}–{int(original.year.max()) if not original.empty else '—'}")
col3.metric("Requested period", f"{FIRST_YEAR}–{LAST_YEAR}")
col4.metric("Retrieved", datetime.now(timezone.utc).strftime("%Y-%m-%d UTC"))
st.write(f"**Definition:** {definition}")
st.write(f"**Units:** {unit} · **Indicator code:** `{indicator_code}`")
st.write(f"**Source:** [World Bank indicator page]({WB_COUNTRY.format(indicator=indicator_code, country=country_code)}) · [API request]({st.session_state.get('source_url', WB_API.format(country=country_code, indicator=indicator_code))})")
st.caption("Actual coverage/count can be smaller than the requested 70-year window because some observations may not exist or may be null.")

is_edited = not original.equals(st.session_state.working_frame.reset_index(drop=True))
if is_edited:
    st.warning("User-modified scenario: the editable data differs from the retrieved source. Model outputs and exports use the validated working table.")

with st.expander("Edit year/value table", expanded=not printer_mode):
    st.caption("Edit only year and value. Blank values are omitted from fitting. Duplicate years, non-integer years, and invalid values are rejected.")
    edited = st.data_editor(st.session_state.working_frame, num_rows="dynamic", use_container_width=True, key=f"editor_{country_code}_{indicator_code}")
    vframe, validation_errors = validate_working_data(edited, indicator_label)
    if validation_errors:
        for err in validation_errors[:12]:
            st.error(err)
        st.caption(f"{len(validation_errors)} validation message(s). Invalid data is not used for fitting.")
        st.stop()
    else:
        st.session_state.working_frame = vframe.copy()
    reset_col, status_col = st.columns([1, 3])
    if reset_col.button("Reset to source", use_container_width=True):
        st.session_state.working_frame = st.session_state.original_frame.copy()
        st.session_state.calculated_years = []
        st.session_state.calculated_results = pd.DataFrame(columns=["year", "estimate", "units", "classification", "status"])
        st.session_state.calculation_key = None
        st.rerun()
    status_col.write("Validation status: " + ("**Fix the errors above before fitting.**" if validation_errors else "**Working table is valid.**"))

working = st.session_state.working_frame.copy()
# Revalidate state in case an editor rerun has not committed a valid table.
working, current_errors = validate_working_data(working, indicator_label)
if current_errors:
    st.error("The working data contains validation errors; fitting is paused.")
    st.stop()
working = working.dropna(subset=["value"]).sort_values("year").reset_index(drop=True)
if working.empty:
    st.warning("No valid observations are available. Try another country/indicator or reset the source table.")
    model = None
else:
    try:
        model = fit_polynomial(working, degree)
    except ValueError as exc:
        model = None
        st.error(str(exc))

if model:
    st.subheader("Polynomial fit")
    st.code(model["equation"])
    metric_cols = st.columns(5)
    metric_cols[0].metric("Degree", model["degree"])
    metric_cols[1].metric("R² · in-sample", f"{model['r2']:.5f}")
    metric_cols[2].metric("MAE · in-sample", f"{model['mae']:.5g} {unit}")
    metric_cols[3].metric("Observations", model["count"])
    metric_cols[4].metric("Mean", f"{model['mean']:.5g} {unit}")
    st.write(f"**Base year:** {model['base_year']} · **Historical fitted range:** {model['min_year']}–{model['max_year']}")
    holdout = chronological_holdout(working, degree)
    if holdout:
        st.write(f"**Chronological holdout** (last {holdout['test_n']} years held out; trained on earlier years): MAE = {holdout['mae']:.5g} {unit}; "
                 + (f"R² = {holdout['r2']:.5f}" if holdout["r2"] is not None else "R² not defined for a one-point test set") +
                 ". This score is separate from the in-sample metrics.")
    else:
        st.caption("Chronological holdout comparison not shown: there are not enough observations to train a degree-d model and retain a useful later test set.")
    with st.expander("Residuals and fitted values"):
        st.dataframe(model["residuals"].rename(columns={"year":"Year","value":"Observed","fitted":"Fitted","residual":"Residual"}), use_container_width=True)
    st.warning("Polynomial fits describe patterns in the selected data; they do not establish historical causes. Extrapolations can become implausible quickly. Residuals and MAE describe in-sample errors, not validated 95% prediction intervals.")

# Calculated year input and batch calculations
st.subheader("Calculate value")
single_year = st.number_input("Single year (1950–2100)", min_value=YEAR_MIN, max_value=YEAR_MAX, value=min(max(LAST_YEAR, YEAR_MIN), YEAR_MAX), step=1)
if st.button("Calculate Value", type="primary", disabled=model is None):
    val = evaluate_poly(model, int(single_year))
    classification = "within fitted historical range" if model["min_year"] <= single_year <= model["max_year"] else "outside fitted historical range (extrapolation)"
    status = "Fitted value at an observed year; not the same as the actual observation." if single_year in set(working.year) else "Model estimate; no actual observation is present for this year."
    new_row = {"year": int(single_year), "estimate": val, "units": unit, "classification": classification, "status": status}
    old = st.session_state.calculated_results
    old = old[old.year != int(single_year)] if not old.empty else old
    st.session_state.calculated_results = pd.concat([old, pd.DataFrame([new_row])], ignore_index=True).sort_values("year")
    st.session_state.calculated_years = st.session_state.calculated_results.year.astype(int).tolist()
    st.session_state.calculation_key = (country_code, indicator_code, degree, tuple(map(tuple, working[["year","value"]].to_numpy().tolist())))
if model and st.session_state.calculation_key is not None:
    expected_key = (country_code, indicator_code, degree, tuple(map(tuple, working[["year","value"]].to_numpy().tolist())))
    if st.session_state.calculation_key != expected_key:
        st.session_state.calculated_results = pd.DataFrame(columns=["year", "estimate", "units", "classification", "status"])
        st.session_state.calculated_years = []
        st.session_state.calculation_key = None
        st.info("Calculated-year results were cleared because the country, indicator, degree, or working data changed.")
if not st.session_state.calculated_results.empty:
    st.dataframe(st.session_state.calculated_results, use_container_width=True)
    st.caption("Batch results use the same centered-time polynomial as single-year calculations.")

with st.expander("Batch year calculations", expanded=False):
    mode = st.radio("Choose batch input", ["Year range", "Custom years"], horizontal=True)
    batch_years = []
    if mode == "Year range":
        c1, c2, c3 = st.columns(3)
        start_y = c1.number_input("Start year", min_value=YEAR_MIN, max_value=YEAR_MAX, value=max(YEAR_MIN, LAST_YEAR-10), step=1)
        end_y = c2.number_input("End year", min_value=YEAR_MIN, max_value=YEAR_MAX, value=min(YEAR_MAX, LAST_YEAR), step=1)
        step_y = c3.slider("Range step", 1, 10, 1)
        if start_y <= end_y:
            batch_years = list(range(int(start_y), int(end_y)+1, int(step_y)))
        else:
            st.error("Start year must be less than or equal to end year.")
    else:
        custom = st.text_input("Comma-separated years", value=f"{max(YEAR_MIN, LAST_YEAR-5)}, {LAST_YEAR}")
        for token in custom.split(","):
            token = token.strip()
            if not token:
                continue
            try:
                if not re.fullmatch(r"[+-]?\d+", token):
                    raise ValueError
                year = int(token)
                if YEAR_MIN <= year <= YEAR_MAX:
                    batch_years.append(year)
                else:
                    st.warning(f"Ignored {token!r}: years must be between {YEAR_MIN} and {YEAR_MAX}.")
            except ValueError:
                st.warning(f"Ignored {token!r}: enter comma-separated integer years.")
        batch_years = sorted(set(batch_years))
    if st.button("Calculate batch", disabled=model is None):
        if not batch_years:
            st.error("Enter at least one valid year.")
        else:
            rows = []
            for y in sorted(set(batch_years)):
                est = evaluate_poly(model, y)
                rows.append({"year": y, "estimate": est, "units": unit,
                             "classification": "within fitted historical range" if model["min_year"] <= y <= model["max_year"] else "outside fitted historical range (extrapolation)",
                             "status": "Fitted value at an observed year; not the same as the actual observation." if y in set(working.year) else "Model estimate; no actual observation is present for this year."})
            st.session_state.calculated_results = pd.DataFrame(rows)
            st.session_state.calculated_years = sorted(set(batch_years))
            st.session_state.calculation_key = (country_code, indicator_code, degree, tuple(map(tuple, working[["year","value"]].to_numpy().tolist())))
            st.rerun()
    if model and batch_years:
        st.caption(f"Valid requested years: {', '.join(map(str, sorted(set(batch_years))))}")

# Comparison fetches same indicator; coverage gaps remain gaps.
comparison_frames = {}
if comparison_labels:
    with st.spinner("Loading comparison-country observations…"):
        for label in comparison_labels:
            try:
                cf, _ = fetch_world_bank(COUNTRIES[label], indicator_code, FIRST_YEAR, LAST_YEAR)
                comparison_frames[label] = cf.dropna(subset=["value"])
            except RuntimeError as exc:
                st.warning(f"{label}: {exc}")

results = st.session_state.calculated_results.copy()
single_plot_year = None
single_plot_value = None
if not results.empty:
    last_result = results.sort_values("year").iloc[-1]
    single_plot_year, single_plot_value = int(last_result.year), float(last_result.estimate)
fig = make_chart(working, model, indicator_label, unit, single_plot_year, single_plot_value,
                 results if not results.empty else None, sample_increment, comparison_frames, horizon=horizon)
st.subheader("Visualization")
if printer_mode:
    st.markdown("### Printer-friendly summary")
    st.write(f"**{country_label} · {indicator_label}** — {definition}")
    st.write(f"Coverage: {int(working.year.min()) if not working.empty else '—'}–{int(working.year.max()) if not working.empty else '—'}; "
             f"observations: {len(working)}; status: {'user-modified scenario' if is_edited else 'source data'}.")
    if model:
        st.write(f"Model: degree {model['degree']}; base year {model['base_year']}; in-sample R² {model['r2']:.5f}; "
                 f"in-sample MAE {model['mae']:.5g} {unit}.")
    st.caption("Print view condenses the key report details. Browser print settings determine page breaks.")
st.pyplot(fig, use_container_width=True)
if comparison_frames:
    st.caption("Country lines show each country's actual available observations. Gaps mean the API did not supply a non-null observation for that year; coverage may differ by country.")

# Mathematical pathway and context-specific function lab
st.divider()
st.header("Function Lab · Algebra 2, Precalculus, and Calculus")
level = st.selectbox("Mathematics pathway", ["Honors Algebra 2", "Precalculus", "Calculus"], index=2)
context = st.selectbox("Context", list(CONTEXTS))
suggest_y, suggest_unit, suggest_x, suggest_xunit, context_blurb = CONTEXTS[context]
with st.expander("Customize context, variables, units, and interval", expanded=True):
    context_description = st.text_area("Context description", context_blurb)
    c1, c2, c3, c4 = st.columns(4)
    y_name = c1.text_input("Dependent variable", suggest_y)
    y_unit = c2.text_input("Dependent units", suggest_unit)
    x_name = c3.text_input("Independent variable", suggest_x)
    x_unit = c4.text_input("Independent units", suggest_xunit)
    interval_cols = st.columns(3)
    x_low = interval_cols[0].number_input("Analysis interval start", value=0.0, step=0.5, format="%.4f")
    x_high = interval_cols[1].number_input("Analysis interval end", value=10.0, step=0.5, format="%.4f")
    current_x_default = min(max(2.0, min(x_low, x_high)), max(x_low, x_high))
    current_x = interval_cols[2].slider("Current input t", min_value=float(min(x_low,x_high)), max_value=float(max(x_low,x_high)), value=float(current_x_default), step=max((abs(x_high-x_low)/100), .01))
    function_source = st.radio("Function source", ["Use historical curve of best fit", "Suggested function", "Parameterized function", "Enter my own function"], horizontal=False)
    suggested = SUGGESTED_FUNCTIONS[context]
    if function_source == "Use historical curve of best fit":
        if model:
            # Convert numpy polynomial to SymPy using the same centered transform.
            poly_expr = sum(sp.Float(c, 14) * (T-model["base_year"])**p for p,c in zip(range(model["degree"], -1, -1), model["coeff"]))
            function_text = str(poly_expr).replace("**", "^")
            st.caption("The historical polynomial is expressed in the original year variable t; the fit's internal centered time is year minus the base year.")
        else:
            function_text = "t"
            st.warning("Historical model unavailable; a simple placeholder is shown until enough valid observations exist.")
    elif function_source == "Suggested function":
        function_text = st.text_input("Suggested function (editable)", suggested)
    elif function_source == "Parameterized function":
        p1, p2, p3, p4 = st.columns(4)
        a = p1.number_input("a", value=1.0, step=0.25)
        b = p2.number_input("b", value=0.5, step=0.25)
        c = p3.number_input("c", value=0.0, step=0.25)
        h = p4.number_input("h", value=0.0, step=0.25)
        K = st.number_input("K (population/logistic scale)", value=100.0, step=10.0)
        r = st.number_input("r (growth rate)", value=0.5, step=0.1)
        parameter_templates = {
            "Business": f"{a}*(t-{h})^2+{c}", "Engineering": f"{a}*sin({b}*t)+{c}",
            "Medical": f"{a}*exp(-{abs(b)}*t)+{c}", "Sports science": f"{a}*t+{b}",
            "Biology": f"{K}/(1+exp(-{r}*(t-{h})))", "Bioengineering": f"{a}*sin({b}*t)+{c}",
            "Economic forecasting": f"{a}*t^2+{b}*t+{c}", "Weather": f"{a}*cos({b}*t)+{c}",
            "Custom": f"{a}*t+{b}",
        }
        function_text = parameter_templates[context]
        st.code(function_text)
    else:
        function_text = st.text_input("Function in variable t", "t^2 - 4*t + 3")
        st.caption("Supported: polynomial arithmetic, rational expressions, exp, log, sqrt, sin, cos, tan, and constants pi/E. Use * for multiplication and ** or ^ for powers.")

if x_low >= x_high:
    st.error("Analysis interval start must be less than the end.")
    expr = None
else:
    try:
        expr = safe_parse_expression(function_text)
        st.success(f"Parsed function: {sp.sstr(expr)}")
    except Exception as exc:
        expr = None
        st.error(str(exc))

if expr is not None and x_low < x_high:
    analysis = calculus_analysis(expr, x_low, x_high, current_x)
    st.markdown(f"**Function:** \\(f(t) = {sp.latex(expr)}\\)")
    st.markdown(f"**First derivative:** \\(f'(t) = {sp.latex(analysis['d1'])}\\)")
    st.markdown(f"**Second derivative:** \\(f''(t) = {sp.latex(analysis['d2'])}\\)")
    st.caption(f"Variable: {x_name} ({x_unit}) · Output: {y_name} ({y_unit}) · {context_description}")
    st.write(f"At {x_name} = {current_x:.5g} {x_unit}:")
    v1, v2, v3 = st.columns(3)
    v1.metric(f"{y_name}, f(t)", "undefined" if analysis["fpoint"] is None else f"{analysis['fpoint']:.6g} {y_unit}")
    v2.metric("Instantaneous rate f′(t)", "undefined" if analysis["slope"] is None else f"{analysis['slope']:.6g} {y_unit}/{x_unit}")
    v3.metric("Second derivative f″(t)", "undefined" if analysis["second"] is None else f"{analysis['second']:.6g} {y_unit}/{x_unit}²")
    if analysis["slope"] is not None and analysis["fpoint"] is not None:
        st.write(f"**Tangent line at the current point:** y = {analysis['fpoint']:.6g} + ({analysis['slope']:.6g})(t − {current_x:.6g})")
    if analysis["secant_slope"] is not None:
        st.write(f"**Average rate of change** on [{x_low:g}, {x_high:g}] = {analysis['secant_slope']:.6g} {y_unit}/{x_unit}.")
        try:
            f_low, f_high = float(analysis["f"](x_low)), float(analysis["f"](x_high))
            st.write(f"**Secant line:** y = {f_low:.6g} + ({analysis['secant_slope']:.6g})(t − {x_low:.6g})")
        except Exception:
            pass
    if context in ("Engineering", "Sports science"):
        st.write(f"**Context interpretation:** f(t) is modeled {y_name}; f′(t) can represent velocity or rate of movement; f″(t) describes how that rate changes (acceleration when f is position).")
    elif context in ("Business", "Economic forecasting"):
        st.write(f"**Context interpretation:** f(t) is modeled {y_name}; f′(t) describes growth/decline per {x_unit}; f″(t) shows whether that rate is increasing or decreasing.")
    elif context in ("Medical", "Bioengineering"):
        st.write(f"**Context interpretation:** f(t) is an illustrative {y_name}; f′(t) describes its instantaneous change and f″(t) describes how that change itself shifts. This is educational, not clinical guidance.")
    else:
        st.write(f"**Context interpretation:** f(t) gives modeled {y_name}; f′(t) is the instantaneous rate of change, and f″(t) describes how the rate changes.")
    domain_notes = numerical_domain_note(expr, x_low, x_high)
    for note in domain_notes:
        st.warning(note)

    show_f = st.checkbox("Show f(t)", True)
    show_d1 = st.checkbox("Show f′(t)", level == "Calculus")
    show_d2 = st.checkbox("Show f″(t)", level == "Calculus")
    xs = np.linspace(x_low, x_high, 1000)
    fig2, ax2 = plt.subplots(figsize=(10, 4.8))
    plotted_values = []
    for enabled, fn, label in [(show_f, analysis["f"], "f(t)"), (show_d1, analysis["fp"], "f′(t)"), (show_d2, analysis["fpp"], "f″(t)")]:
        if enabled:
            with np.errstate(all="ignore"):
                ys = np.asarray(fn(xs), dtype=float)
            if ys.ndim == 0: ys = np.full_like(xs, float(ys))
            ys = np.where(np.isfinite(ys), ys, np.nan)
            # Break at undefined values and large jumps; do not connect across obvious discontinuities.
            if len(ys) > 2:
                dif = np.abs(np.diff(ys))
                finite_dif = dif[np.isfinite(dif)]
                if len(finite_dif):
                    threshold = max(np.nanpercentile(finite_dif, 98)*8, 1e6)
                    breaks = np.where(dif > threshold)[0]
                    ys[breaks+1] = np.nan
            ax2.plot(xs, ys, label=label)
            plotted_values.extend(ys[np.isfinite(ys)].tolist())
    if analysis["fpoint"] is not None:
        ax2.scatter([current_x], [analysis["fpoint"]], marker="o", s=65, label="Current point on f(t)", zorder=5)
    if analysis["slope"] is not None and analysis["fpoint"] is not None:
        tangent = analysis["fpoint"] + analysis["slope"]*(xs-current_x)
        ax2.plot(xs, tangent, linestyle="--", label="Tangent line")
    if analysis["secant_slope"] is not None:
        try:
            yl = float(analysis["f"](x_low))
            secant = yl + analysis["secant_slope"]*(xs-x_low)
            ax2.plot(xs, secant, linestyle=":", label="Secant line")
        except Exception:
            pass
    ax2.axvline(x_low, color="grey", linestyle="--", alpha=.4)
    ax2.axvline(x_high, color="grey", linestyle="--", alpha=.4)
    ax2.set_xlabel(f"{x_name} ({x_unit})")
    ax2.set_ylabel(f"Value / derivative (units differ)")
    ax2.grid(True, alpha=.25)
    ax2.legend(fontsize=8)
    ax2.set_title(f"{context}: function and calculus view")
    fig2.tight_layout()
    st.pyplot(fig2, use_container_width=True)

    if level in ("Precalculus", "Calculus"):
        st.markdown("**Degree, turning points, and concavity**")
        st.write("For polynomials, degree and leading coefficient affect end behavior; turning points are limited by degree. Concavity is read from the sign of the second derivative.")
    if level == "Honors Algebra 2":
        st.write("**Algebra 2 focus:** inspect domain and range on the selected interval, graph shape, end behavior where meaningful, and average rate of change. A polynomial's end behavior depends on its degree and leading coefficient.")
    if level == "Precalculus":
        st.write("**Precalculus focus:** compare average rates across subintervals. Increasing average rates suggest the slope is growing; decreasing average rates suggest it is shrinking. This links graph shape to concavity.")
    if level == "Calculus":
        st.subheader("Calculus analysis")
        st.write("**Critical points** (zeros of f′ found analytically where possible or numerically approximated):")
        if analysis["crit"]:
            st.dataframe(pd.DataFrame(analysis["crit"]).rename(columns={"x":x_name,"y":y_name,"kind":"classification","d2":"f″ at point"}), use_container_width=True)
        else:
            st.write("No interior critical points were found on this interval, or the solver could not certify them.")
        st.write("**Increasing/decreasing intervals:** estimated by checking f′ between critical points; interval labels are numerical.")
        breaks = [x_low] + [c["x"] for c in analysis["crit"]] + [x_high]
        trend_rows = []
        for aa, bb in zip(breaks[:-1], breaks[1:]):
            mid = (aa+bb)/2
            try:
                dval = float(analysis["fp"](mid))
                trend_rows.append({"interval":f"({aa:.5g}, {bb:.5g})", "behavior":"increasing" if dval>0 else "decreasing" if dval<0 else "constant/uncertain"})
            except Exception:
                trend_rows.append({"interval":f"({aa:.5g}, {bb:.5g})", "behavior":"undefined / unable to classify"})
        if trend_rows: st.dataframe(pd.DataFrame(trend_rows), use_container_width=True)
        st.write("**Inflection points:** require a concavity change, not merely f″ = 0.")
        if analysis["inflect"]:
            st.dataframe(pd.DataFrame(analysis["inflect"]), use_container_width=True)
        else:
            st.write("No concavity-changing inflection point was verified analytically on this interval.")
        for label, item in [("Absolute minimum", analysis["abs_min"]), ("Absolute maximum", analysis["abs_max"])]:
            if item:
                st.write(f"**{label} on the selected closed interval (among finite endpoints and found critical points):** {y_name} ≈ {item[1]:.6g} {y_unit} at {x_name} ≈ {item[0]:.6g} {x_unit} ({item[2]}).")
        st.caption("Critical points, roots, discontinuities, and extrema may be numerical approximations. For functions with discontinuities or solver limitations, closed-interval extrema claims require extra care.")
    st.subheader("Interactive visual simulation")
    visual = st.selectbox("Visual metaphor", VISUALS)
    speed = st.select_slider("Playback speed (visual only)", options=["Slow", "Normal", "Fast"], value="Normal")
    play = st.toggle("Play animation", value=False)
    reset = st.button("Reset simulation point")
    if reset:
        st.session_state["sim_point"] = float(x_low)
        st.rerun()
    # Streamlit reruns on user interaction; a deterministic play preview avoids hidden timer loops.
    if "sim_point" not in st.session_state or not (x_low <= st.session_state["sim_point"] <= x_high):
        st.session_state["sim_point"] = float(current_x)
    sim_point = float(st.session_state["sim_point"])
    if play:
        increment = (x_high-x_low) * ({"Slow":0.01,"Normal":0.03,"Fast":0.08}[speed])
        sim_point = x_low if sim_point + increment > x_high else sim_point + increment
        st.session_state["sim_point"] = sim_point
        st.caption("Playback advances one step per Streamlit rerun/interaction; continuous autoplay depends on the hosting client's rerun behavior.")
    try:
        sim_value = float(analysis["f"](sim_point))
        if not np.isfinite(sim_value): raise ValueError
        progress = (sim_point-x_low)/(x_high-x_low)
        if visual == "Walking person / prosthetic-leg example":
            st.markdown(f"🚶 **Walking simulation:** input position {sim_point:.3g} {x_unit}; modeled movement signal {sim_value:.3g} {y_unit}.")
            st.progress(float(np.clip(progress,0,1)))
            st.caption("Illustrative motion indicator only; not a clinical prosthetic design.")
        elif visual == "Moving object / projectile":
            st.markdown(f"🟠 **Moving object:** horizontal progress {progress*100:.1f}%; model output {sim_value:.3g} {y_unit}.")
            st.progress(float(np.clip(progress,0,1)))
        elif visual == "Tank / concentration indicator":
            st.markdown(f"🧪 **Tank/concentration indicator:** current modeled level {sim_value:.3g} {y_unit}.")
            st.progress(float(np.clip(abs(sim_value)/(abs(sim_value)+10),0,1)))
        elif visual == "Population / cell colony":
            st.markdown(f"🦠 **Population indicator:** modeled value {sim_value:.3g} {y_unit}; scale is normalized for display only.")
            st.progress(float(np.clip(abs(sim_value)/(abs(sim_value)+100),0,1)))
        elif visual == "Thermometer / weather indicator":
            st.markdown(f"🌡️ **Weather indicator:** modeled value {sim_value:.3g} {y_unit}; visual bar is normalized, not a forecast.")
            st.progress(float(np.clip((sim_value+50)/100,0,1)))
        else:
            st.markdown(f"📊 **Business/economic indicator:** modeled value {sim_value:.3g} {y_unit}; displayed bar is normalized for visual comparison only.")
            st.progress(float(np.clip(abs(sim_value)/(abs(sim_value)+100),0,1)))
    except Exception:
        st.warning("The function is undefined at the current simulation point; move the point to a valid domain location.")

# Exports reflect current working data, model, chart, results, and edit status.
st.divider()
st.header("Export current project")
summary = {
    "app": APP_TITLE, "retrieval_date_utc": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
    "country": country_label, "country_code": country_code, "indicator": indicator_label,
    "indicator_code": indicator_code, "definition": definition, "units": unit,
    "requested_period": f"{FIRST_YEAR}-{LAST_YEAR}",
    "actual_coverage": f"{int(working.year.min())}-{int(working.year.max())}" if not working.empty else "no valid data",
    "observation_count": int(len(working)), "data_status": "user-modified scenario" if is_edited else "source data",
    "degree": degree, "equation": model["equation"] if model else "not fitted",
    "base_year": model["base_year"] if model else None, "r_squared_in_sample": model["r2"] if model else None,
    "mae_in_sample": model["mae"] if model else None, "mean": model["mean"] if model else None,
    "limitations": "Polynomial extrapolation is uncertain; residual/MAE are not 95% prediction intervals."
}
if model:
    export_working = model["residuals"].rename(columns={"year":"year","value":"observed","fitted":"fitted","residual":"residual"})
else:
    export_working = working.copy()
if not results.empty:
    export_results = results.copy()
else:
    export_results = pd.DataFrame(columns=["year","estimate","units","classification","status"])
st.download_button("Download CSV · working data", data=csv_bytes(export_working), file_name="hispanic_heritage_working_data.csv", mime="text/csv")
st.download_button("Download Excel workbook", data=excel_bytes(summary, export_working, export_results), file_name="hispanic_heritage_explorer.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
pdf_fig = fig
st.download_button("Download PDF report", data=pdf_bytes(summary, export_working, export_results, pdf_fig), file_name="hispanic_heritage_report.pdf", mime="application/pdf")
st.caption("CSV contains working data and model columns when a fit is available. Excel includes Summary, Working Data, and Calculated Years sheets. PDF includes metadata, equation/metrics, chart, limitations, data preview, and calculated results.")

with st.expander("Data, modeling, and interpretation notes"):
    st.markdown("""
- **Data flow:** controls select a country and indicator; the app requests World Bank API observations for the requested period; source data are copied into an editable working table; validation runs before fitting; the fit, chart, calculated values, and exports use the working table.
- **Mathematics:** the historical fit uses \(t = year - base\ year\) to center time and reduce numerical conditioning problems. Degree \(d\) requires at least \(d+1\) distinct years. R² and MAE are in-sample fit measures; the chronological holdout score is separate.
- **Missing data:** null World Bank values remain missing and are excluded from fitting. The app does not invent values or substitute random data.
- **Interpretation:** correlation/trend fit does not prove a cause. GDP per capita is not average wealth or household income; crude birth rate is not a count; net migration is not an emigration count.
- **Extrapolation:** polynomial behavior outside the observed interval may become implausible. Predictions are not clipped. Residuals and MAE are not prediction intervals.
- **Function Lab:** the symbolic expression is parsed with an allowlist; derivatives are symbolic, while critical points and interval classifications may use numerical approximations. A numerical graph is not proof of a theorem.
- **Brazil:** Brazil is a Latin American comparison, but it is Portuguese-speaking and is not generally classified as a Hispanic country.
""")
st.markdown("**Source links:** [World Bank API documentation](https://datahelpdesk.worldbank.org/knowledgebase/articles/889392-about-the-indicators-api-documentation) · [World Bank Open Data](https://data.worldbank.org/)")
