# Sources and data dictionary

## Primary data source

The app retrieves country-year observations from the official World Bank Indicators API:

- API documentation: https://datahelpdesk.worldbank.org/knowledgebase/articles/889392-about-the-indicators-api-documentation
- Open Data portal: https://data.worldbank.org/
- API pattern: `https://api.worldbank.org/v2/country/{ISO3}/indicator/{INDICATOR_CODE}?format=json&per_page=20000&date={START}:{END}`

The app requests years from the current calendar year minus 70 through the current calendar year minus 1, inclusive. It records retrieval date and shows actual non-null coverage/count. World Bank data may have gaps and revisions; the app does not fill gaps with fabricated values.

## Countries

Mexico (MEX), Brazil (BRA), Argentina (ARG), Colombia (COL), Chile (CHL), Peru (PER), Venezuela (VEN), Ecuador (ECU), and Uruguay (URY). Brazil is included as a Latin American regional comparison. Brazil is Portuguese-speaking and is not generally categorized as a Hispanic country.

## Indicator mappings

| Display name | World Bank code | Units | Interpretation |
|---|---|---|---|
| Life expectancy at birth | `SP.DYN.LE00.IN` | years | Expected years a newborn would live if current age-specific mortality patterns persisted. |
| Unemployment, national estimate | `SL.UEM.TOTL.NE.ZS` | % of labor force | Share of labor force without work but available for and seeking employment, using national estimates. |
| GDP per capita | `NY.GDP.PCAP.CD` | current US$ per person | GDP divided by midyear population; not average wealth or household income. |
| Crude birth rate | `SP.DYN.CBRT.IN` | births per 1,000 people per year | Annual live births per 1,000 people; a rate, not a birth count. |
| Net migration | `SM.POP.NETM` | people (net total) | Immigrants minus emigrants over the period; not an emigration count. |
| Intentional homicide rate | `VC.IHR.PSRC.P5` | intentional homicides per 100,000 people | Intentional homicide victims per 100,000 population. |
| Consumer price inflation | `FP.CPI.TOTL.ZG` | % annual change | Annual percentage change in the consumer price index. |
| Central government debt | `GC.DOD.TOTL.GD.ZS` | % of GDP | Central government debt as a share of GDP. |
| Total reserves including gold | `FI.RES.TOTL.CD` | current US$ | Total reserves, including gold, valued in current US dollars. |
| External balance on goods/services | `NE.RSB.GNFS.ZS` | % of GDP | External balance on goods and services as a share of GDP. |

Indicator definitions and coverage can change as the World Bank updates its metadata. Check the linked indicator page before presenting a result as a formal research finding.

## Mathematical methods

- Polynomial regression: NumPy `polyfit` on centered time, `t = year - base year`.
- Fit metrics: scikit-learn in-sample R² and mean absolute error; these are descriptive fit metrics, not confidence or prediction intervals.
- Chronological holdout: later observations are held out when the data count supports a reasonable training/test split.
- Function Lab: SymPy symbolic parsing/differentiation, with numerical sampling for plots and some point classification.
- Exports: pandas CSV, XlsxWriter workbook, ReportLab PDF report.

## Limits

Historical association does not establish causation. Polynomial extrapolation is particularly uncertain beyond observed years. Null observations remain missing. A custom context/function is a mathematical model and is not automatically validated against real-world mechanisms.
